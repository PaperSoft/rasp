import RPi.GPIO as GPIO
import time
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def main():
    return render_template('index.html')

# 테스트 시작하기
@app.route('/computeron')
def start():
    print ("Computer on")
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(18,GPIO.OUT)
    print ("start")
    time.sleep(2)
    GPIO.output(18,True)
    print ("power in")
    time.sleep(2)
    GPIO.cleanup()
    return render_template('computeron.html')
app.run(debug=True)
    